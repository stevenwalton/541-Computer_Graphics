# 541 Graphics Final Project
----------------------------
All files are on my GitHub (private repo)

Included:
- PDF of presentation
    - Contains movies
    - Contains images
    - Contains a screenshot (of Visit setup)
- Scripts used for visit
    - Not all scripts, since these were modified as I went
- This file
- More screenshots
    - Screenshot of Alaska
    - Screenshot of Visit prototyping
